
# Pyronix RP Forum

This is a lightweight roleplay forum inspired by Nexus RP, built for the Pyronix RP server.

## Features
- Complaint Submission Form
- Admin Panel (admin / Pyronix2025!)
- Discord Integration
- Fully in Georgian

## Hosting
This is currently hosted on Vercel but can be deployed to GitHub Pages.

## Live Site
[https://pyronixrp.vercel.app](https://pyronixrp.vercel.app)
